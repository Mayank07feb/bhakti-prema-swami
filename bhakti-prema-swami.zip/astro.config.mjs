// @ts-check
import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import tailwindcss from '@tailwindcss/vite';
import vercel from '@astrojs/vercel/serverless';

export default defineConfig({
  output: 'server', // SSR enabled
  adapter: vercel(), // ✅ REQUIRED for Vercel
  integrations: [react()],
  vite: {
    plugins: [tailwindcss()],
  },
});
