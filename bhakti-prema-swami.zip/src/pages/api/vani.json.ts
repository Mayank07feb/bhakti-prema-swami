import type { APIRoute } from 'astro';

export const GET: APIRoute = async () => {
  // This matches your actual API structure
  const response = {
    data: [
      {
        id: 16,
        name: "Bhagavad-gītā Introduction",
        description: "Before beginning Bhagavad-gītā, I think I shall explain first of all the necessity of understanding this great book of knowledge. We are all searching after knowledge. That is our business. Human life is meant for searching after knowledge.",
        media_ids: "5",
        category_ids: "6,7,8,9",
        location_ids: "6,5,3",
        is_audio_available: "YES",
        publish_date: "1966-02-19",
        audio_url: "/assets/audio/bhagavad-gita-intro.mp3",
        meta_title: "Bhagavad-gītā Introduction",
        meta_description: "Introduction to Bhagavad-gītā by A.C. Bhaktivedanta Swami",
        link: "bhagavad-gita-introduction",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-02-19 00:00:00"
      },
      {
        id: 17,
        name: "Bhagavad-gītā 2.7-11",
        description: "Today we shall discuss the seventh to eleventh verses of the Second Chapter of Bhagavad-gītā. In these verses, Arjuna is expressing his perplexity about the path of duty. Arjuna says, 'Now I am confused about my duty and have lost all composure because of weakness.'",
        media_ids: "5",
        category_ids: "6,7,8",
        location_ids: "6",
        is_audio_available: "YES",
        publish_date: "1966-03-02",
        audio_url: "/assets/audio/bhagavad-gita-2-7-11.mp3",
        meta_title: "Bhagavad-gītā 2.7-11",
        meta_description: "Lecture on Bhagavad-gītā verses 2.7-11",
        link: "bhagavad-gita-2-7-11",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-03-02 00:00:00"
      },
      {
        id: 18,
        name: "Bhagavad-gītā 2.11",
        description: "In this verse, Lord Kṛṣṇa begins His instruction to Arjuna with the words, 'While speaking learned words, you are mourning for what is not worthy of grief. Those who are wise lament neither for the living nor the dead.' This is a very important verse.",
        media_ids: "5",
        category_ids: "6,7",
        location_ids: "6,3",
        is_audio_available: "YES",
        publish_date: "1966-03-04",
        audio_url: "/assets/audio/bhagavad-gita-2-11.mp3",
        meta_title: "Bhagavad-gītā 2.11",
        meta_description: "Lecture on Bhagavad-gītā verse 2.11",
        link: "bhagavad-gita-2-11",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-03-04 00:00:00"
      },
      {
        id: 19,
        name: "Bhagavad-gītā 2.12",
        description: "Today we will discuss verse 2.12 of Bhagavad-gītā, where Lord Kṛṣṇa says: 'Never was there a time when I did not exist, nor you, nor all these kings; nor in the future shall any of us cease to be.' This is a very important statement about the eternality of the living entity.",
        media_ids: "5",
        category_ids: "6",
        location_ids: "6",
        is_audio_available: "NO",
        publish_date: "1966-03-07",
        audio_url: null,
        meta_title: "Bhagavad-gītā 2.12",
        meta_description: "Lecture on Bhagavad-gītā verse 2.12",
        link: "bhagavad-gita-2-12",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-03-07 00:00:00"
      },
      {
        id: 20,
        name: "Bhagavad-gītā 2.13",
        description: "In this verse, Kṛṣṇa explains: 'As the embodied soul continuously passes, in this body, from boyhood to youth to old age, the soul similarly passes into another body at death. A sober person is not bewildered by such a change.' This verse describes the process of transmigration of the soul.",
        media_ids: "5",
        category_ids: "6,7,8",
        location_ids: "6,5",
        is_audio_available: "YES",
        publish_date: "1966-03-11",
        audio_url: "/assets/audio/bhagavad-gita-2-13.mp3",
        meta_title: "Bhagavad-gītā 2.13",
        meta_description: "Lecture on Bhagavad-gītā verse 2.13",
        link: "bhagavad-gita-2-13",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-03-11 00:00:00"
      },
      {
        id: 21,
        name: "Purport to Bhajahū Re Mana",
        description: "This song, 'Bhajahū Re Mana,' was composed by Govinda dāsa, a great Vaiṣṇava poet. The song is a heartfelt appeal to the mind to engage in devotional service. 'Bhajahū re mana' means 'O my mind, please worship.'",
        media_ids: "8",
        category_ids: "9",
        location_ids: "6",
        is_audio_available: "YES",
        publish_date: "1966-03-30",
        audio_url: "/assets/audio/bhajahu-re-mana.mp3",
        meta_title: "Purport to Bhajahū Re Mana",
        meta_description: "Purport to devotional song Bhajahū Re Mana",
        link: "purport-bhajahu-re-mana",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-03-30 00:00:00"
      },
      {
        id: 22,
        name: "Bhagavad-gītā 2.48-49",
        description: "In these verses, Kṛṣṇa continues to explain the nature of yoga. He says, 'Perform your duty equipoised, O Arjuna, abandoning all attachment to success or failure. Such equanimity is called yoga.' This is the definition of yoga—maintaining equanimity in all circumstances.",
        media_ids: "5",
        category_ids: "6,7",
        location_ids: "6",
        is_audio_available: "YES",
        publish_date: "1966-04-01",
        audio_url: "/assets/audio/bhagavad-gita-2-48-49.mp3",
        meta_title: "Bhagavad-gītā 2.48-49",
        meta_description: "Lecture on Bhagavad-gītā verses 2.48-49",
        link: "bhagavad-gita-2-48-49",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-04-01 00:00:00"
      },
      {
        id: 23,
        name: "Bhagavad-gītā 2.51-55",
        description: "In these concluding verses of this section, Arjuna asks Kṛṣṇa about the characteristics of a person who is fixed in transcendental consciousness. 'What are the symptoms of one whose consciousness is thus merged in transcendence? How does he speak, and what is his language?'",
        media_ids: "5",
        category_ids: "6,7,8,9",
        location_ids: "6,5,3",
        is_audio_available: "YES",
        publish_date: "1966-04-06",
        audio_url: "/assets/audio/bhagavad-gita-2-51-55.mp3",
        meta_title: "Bhagavad-gītā 2.51-55",
        meta_description: "Lecture on Bhagavad-gītā verses 2.51-55",
        link: "bhagavad-gita-2-51-55",
        is_active_or_inactive: "YES",
        created_at_utc: "1966-04-06 00:00:00"
      }
    ],
    // Filter options based on your category_ids, location_ids, media_ids
    filters: {
      audio: [
        { label: "Has Audio", value: "YES", count: 7 },
        { label: "No Audio", value: "NO", count: 1 }
      ],
      categories: [
        { id: "6", label: "Bhagavad-gita", count: 7 },
        { id: "7", label: "Philosophy", count: 5 },
        { id: "8", label: "Devotion", count: 3 },
        { id: "9", label: "Songs", count: 2 }
      ],
      locations: [
        { id: "6", label: "New York", count: 8 },
        { id: "5", label: "Los Angeles", count: 3 },
        { id: "3", label: "London", count: 2 }
      ],
      years: [
        { label: "1966", value: "1966", count: 8 }
      ]
    }
  };

  return new Response(JSON.stringify(response), {
    headers: {
      "Content-Type": "application/json",
    },
  });
};