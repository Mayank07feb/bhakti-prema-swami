// Centralized SEO data for all pages
export const seoData = {
  default: {
    meta_title: "Bhakti Prema Swami",
    meta_description: "Official website of Bhakti Prema Swami, sharing teachings and resources on Bhakti Yoga."
  },

  about: {
    meta_title: "About Bhakti Prema Swami",
    meta_description: "Learn about the life, early years, and teachings of Bhakti Prema Swami."
  },

  media: {
    meta_title: "Media - Bhakti Prema Swami",
    meta_description: "Explore videos, audios, and photo galleries of Bhakti Prema Swami's teachings and events."
  },

  books: {
    meta_title: "Books by Bhakti Prema Swami",
    meta_description: "Discover the spiritual books and publications authored by Bhakti Prema Swami."
  },

  connect: {
    meta_title: "Connect with Bhakti Prema Swami",
    meta_description: "Get in touch with Bhakti Prema Swami or his organization for guidance, events, and community."
  },

  calendar: {
    meta_title: "Calendar - Bhakti Prema Swami",
    meta_description: "Check upcoming events, lectures, and programs related to Bhakti Prema Swami."
  },

  course: {
    meta_title: "Course - Bhakti Prema Swami",
    meta_description: "Learn about Bhakti Yoga through courses and teachings offered by Bhakti Prema Swami."
  }
};
